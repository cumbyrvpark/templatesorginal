import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-style-two',
  templateUrl: './blog-style-two.component.html',
  styleUrls: ['./blog-style-two.component.scss']
})
export class BlogStyleTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
