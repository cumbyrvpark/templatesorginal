import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services-style-two',
  templateUrl: './services-style-two.component.html',
  styleUrls: ['./services-style-two.component.scss']
})
export class ServicesStyleTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
